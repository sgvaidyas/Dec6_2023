l = [ "11","aa","ddd"]
s = (",").join(l)
print(s)