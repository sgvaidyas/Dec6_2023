#pass by reference
def addrec(master):
    name = input("Enter name = ")
    master.append(name)

master = []
addrec(master)
addrec(master)
addrec(master)
print(master)