fp = open('myfile','r')
content = fp.read()
mylines = content.splitlines()
print(mylines)
for x in mylines:
    mywords = x.split(',')
    for word in mywords:
        print(word.ljust(10),end=" ")
    print()
fp.close()