num = eval(input("Enter the value of num = "))
den = eval(input("Enter the value of den = "))
try:
    res = num/den
    print(res)
except ZeroDivisionError:
    print("Some exception occured : denominator is 0")
except Exception as e:
    print("Generic error", e)

print("hey this is last line")
