#call by value
def myfun(data):
    data = data + 100
    print("inside fun = ",data)

data = 10
print(data)
myfun(data)
print("after fun" ,data)