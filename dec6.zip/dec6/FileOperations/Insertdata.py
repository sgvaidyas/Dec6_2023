def createRec():
    id = input("Enter ID  = ")
    name = input("Enter name = ")
    sub = input("Enter sub = ")
    return [id,name,sub]

def writedata(filename):
    fp = open(filename,'a')
    rec = createRec()           #rec = [ "11","aa","ddd"]
    recStr = (",").join(rec)    #11,aa,ddd
    fp.write(recStr+"\n")
    fp.close()

def readFile(filename):
    try:
        fp = open(filename,'r')
        print("the file data is below\n\n")
        print(fp.read())
        fp.close()
    except FileNotFoundError:
        print("the file does not exist")