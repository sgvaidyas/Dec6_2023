isexcept = False
try:
    val = int(input("Enter age = "))
except ValueError:
    isexcept = True
    print("value should be int ")
else:
    if val>18:
        print("Eligible to vote")
    else:
        print("Not eligible to vote")
finally:
    if(isexcept == True):
        ch = input("do u want to proceed ? if yes press Y")
        if(ch == "Y"):
            print(" i just am here because u chose yes")

print("--------------------------")