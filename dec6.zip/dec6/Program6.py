import copy
l = [1,2,3,4,5]
a = copy.copy(l)
print(a, l)
a[2] = 999
print(a,l)