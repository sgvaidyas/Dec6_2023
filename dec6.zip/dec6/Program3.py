l = ["aaa","bbb","ccc","ddd"]

ind = int(input("Enter a int val = "))
try:
    print("this is the value", l[ind],"  of list at index = ",ind)
except IndexError:
    print("Index is out of range")
print("---------------------")


