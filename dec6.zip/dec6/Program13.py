'''fp = open('myfile2' , 'w')
fp.write("hey this is just me\n")
fp.close()
'''

fp = open('myfile2' , 'a')
fp.write("aaaaaaaaaaaaa\n")
fp.write("ccccccccccc\n")

fp.close()
