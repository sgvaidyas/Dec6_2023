import copy
l = [11,22,33,[10,20,30]]
a = copy.deepcopy(l)
print(a)
print(l)
a[3][1] = 999
print(a)
print(l)
