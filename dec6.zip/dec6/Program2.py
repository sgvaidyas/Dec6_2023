a = eval(input("Enter data1 = "))
b = eval(input("Enter data2 = "))
try:
    print(a/b)
except TypeError:
    print("Mismatched data types")
except ZeroDivisionError:
    print("divide by 0 error")
except Exception as e:
    print("Generic = ",e)
print("=====================")