from FileOperations import *

readFile('records')
writedata('records')
writedata('records')
readFile('records')
