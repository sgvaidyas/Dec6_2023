#dictionaries
d = {'name':'Shilpa', 'id':111,'sal':900}
k = input("Enter key = ")
try:
    print("Value of ",k," is = ",d[k])
except KeyError:
    print("the key does not exist in dictionary")
else:
    if k == 'id':
        d[k]=d[k]+10
        print("new d = ",d)
    print("i will be executed : ELSE")






'''print(d)
print(d.keys())
print(d.values())
print(d.items())
print(d['name'])'''