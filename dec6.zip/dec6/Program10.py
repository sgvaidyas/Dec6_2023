try:
    fp = open('myfile','r')
    content = fp.read()
    print(content)
    fp.close()
except FileNotFoundError:
    print("the file does not exist")
except Exception as e:
    print("Generic Exception : ",e)
finally:
    pass