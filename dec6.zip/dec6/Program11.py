s = "apple"
print(s.upper())

s = "APPLE"
print(s.lower())

a = "hi this is just a line"
print(a.capitalize())
print(a.title())

a = "Hi This IS A sample"
print(a.swapcase())

a = "apple"
#a.center(40,"*")
print(a.center(40,"*"))
print(a.ljust(40,"*"))
print(a.rjust(40,"*"))

a = "Apple"
b = "MANGO"
print(a+b)

a = "hi this is me "
print(a.split())
a = "hi, this is , me"
print(a.split(","))
a = " hi this \n is me and \ni am awesome"
print(a)
print(a.splitlines())



